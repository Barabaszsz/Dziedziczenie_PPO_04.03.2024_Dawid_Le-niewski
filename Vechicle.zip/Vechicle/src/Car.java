public class Car extends Vechicle {
    protected String brand ="Ford";
    protected String model ="Mustang";
    protected int mileage = 78000;
    protected int price = 60000;

    /********************************************************
     * nazwa funkcji: sound
     * parametry wejściowe: "Wruum!"
     * wartość zwracana: Dzwięk silnika
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void sound(){
        System.out.println("Wruum!");
    }
    /********************************************************
     * nazwa funkcji: horsepower
     * parametry wejściowe: "120 hp"
     * wartość zwracana: Konie mechaniczne
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void horsepower (){
        System.out.println("120 hp");
    }
    /********************************************************
     * nazwa funkcji: gene
     * parametry wejściowe: "First"
     * wartość zwracana: Generacja
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void gene(){
        System.out.println("First");
    }
}
