public class Main {
    public static void main(String[] args) {
        Vechicle vech = new Vechicle();
        vech.generation();
        vech.engine();
        vech.honk();
        Car car = new Car();
        car.gene();
        car.horsepower();
        car.sound();
        Plane plane = new Plane();
        plane.crew();
        plane.howmanythereis();
        plane.yearofproduction();

    }
}