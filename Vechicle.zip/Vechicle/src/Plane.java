public class Plane extends Vechicle{
    protected String brand ="Boeing";
    protected String model ="737";
    private String speed = "800km";
    protected int price = 100000000;

    /********************************************************
     * nazwa funkcji: crew
     * parametry wejściowe: "2"
     * wartość zwracana: Liczba osób w załodze
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void crew(){
        System.out.println("2");
    }
    /********************************************************
     * nazwa funkcji: yearofproduction
     * parametry wejściowe: "1968"
     * wartość zwracana: Rok produkcji
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void yearofproduction(){
        System.out.println("1968");
    }
    /********************************************************
     * nazwa funkcji: howmanythereis
     * parametry wejściowe: "10 271"
     * wartość zwracana: Ile ich jest na świecie
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void howmanythereis(){
        System.out.println("10 271");
    }
}
