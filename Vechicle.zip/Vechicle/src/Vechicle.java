public class Vechicle {
    protected String brand ="Mazda";
    protected String model ="MX5";
    protected int mileage = 34000;
    protected int price = 40000;

    /********************************************************
     * nazwa funkcji: honk
     * parametry wejściowe: "Tuut!"
     * wartość zwracana: Dziwięk klaksonu
     * autor: Dawid Leśniewski
     * ****************************************************/

    public void honk(){
        System.out.println("Tuut!");
    }
    /********************************************************
     * nazwa funkcji: engine
     * parametry wejściowe: "181 hp"
     * wartość zwracana: Konie mechaniczne
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void engine(){
        System.out.println("181 hp");
    }
    /********************************************************
     * nazwa funkcji: generation
     * parametry wejściowe: "First"
     * wartość zwracana: generacja
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void generation(){
        System.out.println("First");
    }

}
